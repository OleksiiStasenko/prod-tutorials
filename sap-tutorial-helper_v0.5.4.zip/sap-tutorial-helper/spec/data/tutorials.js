'use babel';

export default {
  invalid: {
    bufferRow: 7,
    decorations: 1,
  },
};

'use babel';

import path from 'path';

import constants from '../lib/constants';
import { atomHelpers, promisifiedFunctions } from '../lib/helpers';
import commitSelectionPackage from '../lib/modules/commit-selection';
import InputDialog from '../lib/modules/commit-selection/input-dialog';
import { dispatchCommand, setQaRepoPath, spyOnExec, setAutoUpdate } from './spec-helper';

const { COMMON, MESSAGES } = constants;

describe(`${COMMON.PLUGIN_NAME}. Commit Selection`, () => {
  const TREE_VIEW_PACKAGE = 'tree-view';
  const COMMIT_SELECTION_COMMAND = `${COMMON.PLUGIN_NAME}:push-to-qa`;
  const CONFIRM_COMMAND = 'core:confirm';
  const CANCEL_COMMAND = 'core:cancel';

  const parentElement = document.createElement('div');

  parentElement.classList.add('selected');
  parentElement.classList.add('directory');

  function spyOnHelpers() {
    spyOn(promisifiedFunctions, 'statAsync')
      .andCallFake(() => {
        Promise.resolve({ isDirectory: () => false });
      });
    spyOn(promisifiedFunctions, 'readDirAsync')
      .andCallFake(() => {
        Promise.resolve([
          path.join(__dirname, COMMON.TUTORIALS_DIR_NAME, 'tutorials'),
          path.join(__dirname, COMMON.TUTORIALS_DIR_NAME, 'tutorial1'),
        ]);
      });
    spyOn(atomHelpers, 'getOriginUrl')
      .andReturn('some url');
    spyOn(atomHelpers, 'getRepo')
      .andReturn({ workingDirectory: __dirname });
  }

  function prepareEnv({ spyOnExec } = { spyOnExec: true }) {
    spyOn(commitSelectionPackage, 'validate')
      .andCallFake(() => Promise.resolve());
    setQaRepoPath();
    setAutoUpdate(false);

    waitsForPromise({
      shouldReject: false,
      label: 'tree view activation',
    }, () => atom.packages.activatePackage(TREE_VIEW_PACKAGE));
    waitsForPromise({
      shouldReject: false,
      label: 'our package activation',
    }, () => atom.packages.activatePackage(COMMON.PLUGIN_NAME));


    const workspaceElement = atom.views.getView(atom.workspace);
    jasmine.attachToDOM(workspaceElement);
    workspaceElement.style.minHeight = `${document.body.clientHeight}px`;

    workspaceElement.appendChild(parentElement);

    spyOn(commitSelectionPackage, 'setExecutor')
      .andCallFake(() => {
        if (!commitSelectionPackage.executor) {
          commitSelectionPackage.executor = {
            async exec() {
              return {
                stdout: 'lorem',
                stderr: '',
              };
            },

            async runCommand() {
              return {
                stdout: 'lorem',
                stderr: '',
              };
            },
          };
        }
      });

    commitSelectionPackage.setExecutor();

    if (spyOnExec) {
      spyOn(commitSelectionPackage.executor, 'exec')
        .andCallThrough();
      spyOn(commitSelectionPackage.executor, 'runCommand')
        .andCallThrough();
    }

    spyOnHelpers();
  }

  let dialogPanel;

  const dispatchCommitCommand = (waitForDialog = true) => {
    let called = false;

    const disposable = atom.commands.onDidDispatch(({ type }) => {
      if (type === COMMIT_SELECTION_COMMAND) {
        called = true;
        disposable.dispose();
      }
    });
    atom.commands.dispatch(parentElement, COMMIT_SELECTION_COMMAND);

    waitsFor(() => called, `${COMMIT_SELECTION_COMMAND} to be called`);

    if (waitForDialog) {
      waitsFor(() => {
        dialogPanel = atom.workspace.getModalPanels()
          .find(({ item }) => item instanceof InputDialog);
        return !!dialogPanel;
      }, `${COMMIT_SELECTION_COMMAND} dialog to be shown`, 10000);
    }
  };

  afterEach(() => {
    dialogPanel = undefined;
  });

  describe('Select elements from wrong folder', () => {
    beforeEach(() => {
      prepareEnv();
      spyOn(commitSelectionPackage, 'consumeTreeView')
        .andCallFake(() => {
          commitSelectionPackage.treeView = {
            selectedPaths() {
              return ['wrong'];
            },
          };
        });

      dispatchCommand(parentElement, COMMIT_SELECTION_COMMAND);
    });

    it('should show notification', () => {
      const isValid = atom.notifications.getNotifications()
        .some(n => n.message === MESSAGES.PUSH_TO_QA.NOTIFICATIONS.NOT_TUTORIAL);

      expect(isValid)
        .toBe(true);
    });

    it('should not call module executor', () => {
      expect(commitSelectionPackage.executor.runCommand)
        .not
        .toHaveBeenCalled();
    });
  });

  describe('Select folder from wip and commit', () => {
    const filePath = path.join(__dirname, COMMON.WIP_DIR_NAME, 'some-file.md');
    const message = 'Commit message';

    beforeEach(() => {
      prepareEnv();
      spyOn(commitSelectionPackage, 'consumeTreeView')
        .andCallFake(() => {
          commitSelectionPackage.treeView = {
            selectedPaths() {
              return [filePath];
            },
          };
        });
    });

    it('should show dialog, call all the commands and show notification', () => {
      dispatchCommitCommand();

      runs(() => {
        expect(dialogPanel)
          .toBeDefined();

        expect(commitSelectionPackage.validate)
          .toHaveBeenCalled();

        dialogPanel.item.miniEditor.setText(message);
        dispatchCommand(dialogPanel.item.element, CONFIRM_COMMAND);
      });

      waitsFor(() => atom.notifications.getNotifications()
        .some(n => n.message === MESSAGES.PUSH_TO_QA.NOTIFICATIONS.PUSH_SUCCESS_TITLE));
    });

    it('should show dialog, call nothing after cancel', () => {
      dispatchCommitCommand();
      runs(() => {
        expect(dialogPanel)
          .toBeDefined();

        dialogPanel.item.miniEditor.setText(message);
        dispatchCommand(dialogPanel.item.element, CANCEL_COMMAND);
      });

      expect(commitSelectionPackage.executor.runCommand.callCount)
        .toEqual(0);
      expect(commitSelectionPackage.executor.exec)
        .not
        .toHaveBeenCalled();
    });
  });

  describe('Select folder from tutorials and commit', () => {
    const filePath = path.join(__dirname, COMMON.TUTORIALS_DIR_NAME, 'some-file.md');
    const message = 'Commit message';

    beforeEach(() => {
      prepareEnv();
      spyOn(commitSelectionPackage, 'consumeTreeView')
        .andCallFake(() => {
          commitSelectionPackage.treeView = {
            selectedPaths() {
              return [filePath];
            },
          };
        });
    });

    it('should show dialog', () => {
      dispatchCommitCommand();
      runs(() => {
        expect(dialogPanel)
          .toBeDefined();
      });
    });

    it('should call exec 2 times', () => {
      dispatchCommitCommand();
      runs(() => {
        expect(dialogPanel)
          .toBeDefined();

        dialogPanel.item.miniEditor.setText(message);
        dispatchCommand(dialogPanel.item.element, CONFIRM_COMMAND);
      });

      waitsFor(() => commitSelectionPackage.executor.exec.callCount > 1);

      runs(() => {
        expect(commitSelectionPackage.executor.exec.callCount)
          .toEqual(3);
      });
    });

    it('should show start notification', () => {
      dispatchCommitCommand();

      runs(() => {
        expect(dialogPanel)
          .toBeDefined();

        dialogPanel.item.miniEditor.setText(message);
        dispatchCommand(dialogPanel.item.element, CONFIRM_COMMAND);
      });

      waitsFor(() => atom.notifications.getNotifications()
        .some(n => n.message === MESSAGES.PUSH_TO_QA.NOTIFICATIONS.PUSH_START));

      runs(() => {
        const exists = atom.notifications.getNotifications()
          .some(n => n.message === MESSAGES.PUSH_TO_QA.NOTIFICATIONS.PUSH_START);

        expect(exists)
          .toBeTruthy();
      });
    });

    it('should show end notification', () => {
      dispatchCommitCommand();
      runs(() => {
        expect(dialogPanel)
          .toBeDefined();

        dialogPanel.item.miniEditor.setText(message);
        dispatchCommand(dialogPanel.item.element, CONFIRM_COMMAND);
      });

      waitsFor(() => atom.notifications.getNotifications()
        .some(({ message }) => message === MESSAGES.PUSH_TO_QA.NOTIFICATIONS.PUSH_SUCCESS_TITLE));

      runs(() => {
        const exists = atom.notifications.getNotifications()
          .some(({ message }) => message === MESSAGES.PUSH_TO_QA.NOTIFICATIONS.PUSH_SUCCESS_TITLE);

        expect(exists)
          .toBeTruthy();
      });
    });
  });

  describe('Emulating keyboard event', () => {
    const filePath = path.join(__dirname, COMMON.TUTORIALS_DIR_NAME, 'some-file.md');

    function callCommitCommand() {
     const originalEvent = new KeyboardEvent("keydown", {bubbles : true, cancelable : true, key : "Q", char : "Q", shiftKey : true});

     waitsForPromise(() => commitSelectionPackage.commitSelection({
       originalEvent,
       target: parentElement,
       detail: {
         isBackground: true,
       }
     }));
    }

    beforeEach(() => {
      prepareEnv();
      spyOn(commitSelectionPackage, 'consumeTreeView')
        .andCallFake(() => {
          commitSelectionPackage.treeView = {
            selectedPaths() {
              return [filePath];
            },
          };
        });
    });

    it('should not show dialog due to isBackground set to true', () => {
      callCommitCommand();
      runs(() => {
        expect(dialogPanel)
          .not
          .toBeDefined();
      });
    });

    it('should show start notification', () => {
      callCommitCommand();

      waitsFor(() => atom.notifications.getNotifications()
        .some(n => n.message === MESSAGES.PUSH_TO_QA.NOTIFICATIONS.PUSH_START));

      runs(() => {
        const exists = atom.notifications.getNotifications()
          .some(n => n.message === MESSAGES.PUSH_TO_QA.NOTIFICATIONS.PUSH_START);

        expect(exists)
          .toBeTruthy();
      });
    });

    it('should show end notification', () => {
      callCommitCommand();

      waitsFor(() => atom.notifications.getNotifications()
        .some(({ message }) => message === MESSAGES.PUSH_TO_QA.NOTIFICATIONS.PUSH_SUCCESS_TITLE));

      runs(() => {
        const exists = atom.notifications.getNotifications()
          .some(({ message }) => message === MESSAGES.PUSH_TO_QA.NOTIFICATIONS.PUSH_SUCCESS_TITLE);

        expect(exists)
          .toBeTruthy();

        expect(commitSelectionPackage.validate).not.toHaveBeenCalled();
      });
    });
  });

  describe('Emulating synthetic event with validate false in detail', () => {
    const filePath = path.join(__dirname, COMMON.TUTORIALS_DIR_NAME, 'some-file.md');

    function callCommitCommand() {
     waitsForPromise(() => commitSelectionPackage.commitSelection({
       target: parentElement,
       detail: {
         isBackground: true,
         validate: false,
       }
     }));
    }

    beforeEach(() => {
      prepareEnv();
      spyOn(commitSelectionPackage, 'consumeTreeView')
        .andCallFake(() => {
          commitSelectionPackage.treeView = {
            selectedPaths() {
              return [filePath];
            },
          };
        });
    });

    it('should not show dialog due to isBackground set to true', () => {
      callCommitCommand();
      runs(() => {
        expect(dialogPanel)
          .not
          .toBeDefined();
      });
    });

    it('should show start notification', () => {
      callCommitCommand();

      waitsFor(() => atom.notifications.getNotifications()
        .some(n => n.message === MESSAGES.PUSH_TO_QA.NOTIFICATIONS.PUSH_START));

      runs(() => {
        const exists = atom.notifications.getNotifications()
          .some(n => n.message === MESSAGES.PUSH_TO_QA.NOTIFICATIONS.PUSH_START);

        expect(exists)
          .toBeTruthy();
      });
    });

    it('should show end notification', () => {
      callCommitCommand();

      waitsFor(() => atom.notifications.getNotifications()
        .some(({ message }) => message === MESSAGES.PUSH_TO_QA.NOTIFICATIONS.PUSH_SUCCESS_TITLE));

      runs(() => {
        const exists = atom.notifications.getNotifications()
          .some(({ message }) => message === MESSAGES.PUSH_TO_QA.NOTIFICATIONS.PUSH_SUCCESS_TITLE);

        expect(exists)
          .toBeTruthy();

        expect(commitSelectionPackage.validate).not.toHaveBeenCalled();
      });
    });
  });

  describe('Error while committing', () => {
    const filePath = path.join(__dirname, 'data', COMMON.TUTORIALS_DIR_NAME, 'some-file.md');
    const errorMessage = 'Error';

    beforeEach(() => {
      spyOn(commitSelectionPackage, 'consumeTreeView')
        .andCallFake(() => {
          commitSelectionPackage.treeView = {
            selectedPaths() {
              return [filePath];
            },
          };
        });
      prepareEnv({ spyOnExec: false });
    });

    it('should show end notification', () => {
      spyOn(commitSelectionPackage.executor, 'runCommand')
        .andCallFake(() => Promise.reject(new Error(errorMessage)));

      dispatchCommitCommand(false);

      waitsFor(() => atom.notifications.getNotifications().length > 0);

      waitsFor(() => atom.notifications.getNotifications()
        .some(({ message }) => message === errorMessage));

      runs(() => {
        const exists = atom.notifications.getNotifications()
          .some(({ message }) => message === errorMessage);

        expect(exists)
          .toBeTruthy();
      });
    });

    it('should not call stat', () => expect(promisifiedFunctions.statAsync)
      .not
      .toHaveBeenCalled());
  });
});

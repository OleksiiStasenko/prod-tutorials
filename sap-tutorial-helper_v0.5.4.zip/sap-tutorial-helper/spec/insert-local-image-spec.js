'use babel';

import constants from '../lib/constants';
import module from '../lib/modules/insert-local-image';
import { notification, atomHelpers } from '../lib/helpers';
import { dispatchCommand, setQaRepoPath, setAutoUpdate } from './spec-helper';

const { COMMON, MESSAGES } = constants;

describe('Insert Local Image Context Menu', () => {
  describe('Image from tutorials/tutorial-name', () => {
    it('should correctly extract parent tutorial folder path from image path', () => {
      module.treeView = {
        selectedPaths() {
          return [`C:\\Users\\Username\\Tutorials\\${COMMON.TUTORIALS_DIR_NAME}\\tutorial-name\\tutorial-image.png`];
        },
      };
      const imagePath = module.getImagePath();
      const { tutorialFilePath, tutorialFolderPath } = module.getTutorialPaths(imagePath);

      expect(tutorialFolderPath)
        .toEqual(`C:\\Users\\Username\\Tutorials\\${COMMON.TUTORIALS_DIR_NAME}\\tutorial-name`);
      expect(tutorialFilePath)
        .toEqual(`C:\\Users\\Username\\Tutorials\\${COMMON.TUTORIALS_DIR_NAME}\\tutorial-name\\tutorial-name.md`);
    });
  });

  describe('Image from work-in-progress/tutorial-name', () => {
    it('should correctly extract parent tutorial folder path from image path', () => {
      module.treeView = {
        selectedPaths() {
          return [`C:\\Users\\Username\\Tutorials\\${COMMON.WIP_DIR_NAME}\\tutorial-name\\tutorial-image.png`];
        },
      };
      const imagePath = module.getImagePath();
      const { tutorialFilePath, tutorialFolderPath } = module.getTutorialPaths(imagePath);

      expect(tutorialFolderPath)
        .toEqual(`C:\\Users\\Username\\Tutorials\\${COMMON.WIP_DIR_NAME}\\tutorial-name`);
      expect(tutorialFilePath)
        .toEqual(`C:\\Users\\Username\\Tutorials\\${COMMON.WIP_DIR_NAME}\\tutorial-name\\tutorial-name.md`);
    });
  });

  describe('Image in subfolder', () => {
    it('should correctly extract parent tutorial folder path from image path', () => {
      module.treeView = {
        selectedPaths() {
          return [`C:\\Users\\Username\\Tutorials\\${COMMON.TUTORIALS_DIR_NAME}\\tutorial-name\\images\\tutorial-image.png`];
        },
      };
      const imagePath = module.getImagePath();
      const { tutorialFilePath, tutorialFolderPath } = module.getTutorialPaths(imagePath);

      expect(tutorialFolderPath)
        .toEqual(`C:\\Users\\Username\\Tutorials\\${COMMON.TUTORIALS_DIR_NAME}\\tutorial-name`);
      expect(tutorialFilePath)
        .toEqual(`C:\\Users\\Username\\Tutorials\\${COMMON.TUTORIALS_DIR_NAME}\\tutorial-name\\tutorial-name.md`);
    });
  });

  describe('Image in subfolder: depth 2', () => {
    it('should correctly extract parent tutorial folder path from image path', () => {
      module.treeView = {
        selectedPaths() {
          return [`C:\\Users\\Username\\Tutorials\\${COMMON.TUTORIALS_DIR_NAME}\\tutorial-name\\images\\images\\tutorial-image.png`];
        },
      };
      const imagePath = module.getImagePath();
      const { tutorialFilePath, tutorialFolderPath } = module.getTutorialPaths(imagePath);

      expect(tutorialFolderPath)
        .toEqual(`C:\\Users\\Username\\Tutorials\\${COMMON.TUTORIALS_DIR_NAME}\\tutorial-name`);
      expect(tutorialFilePath)
        .toEqual(`C:\\Users\\Username\\Tutorials\\${COMMON.TUTORIALS_DIR_NAME}\\tutorial-name\\tutorial-name.md`);
    });
  });

  describe('Image in non tutorials/wip folder', () => {
    beforeEach(() => {
      spyOn(notification, 'addError')
        .andCallThrough();
    });

    it('should show expected error message', () => {
      module.treeView = {
        selectedPaths() {
          return ['C:\\Users\\Username\\Tutorials\\wrong\\tutorial-name\\images\\images\\tutorial-image.png'];
        },
      };
      module.insertTemplate();

      expect(notification.addError)
        .toHaveBeenCalledWith(MESSAGES.INSERT_LOCAL_IMAGE.NOTIFICATIONS.WRONG_IMAGE_LOCATION);
    });
  });

  describe('No editor', () => {
    beforeEach(() => {
      spyOn(notification, 'addError')
        .andCallThrough();
      spyOn(atomHelpers, 'getEditorForPath')
        .andReturn(null);
    });

    it('should show expected error message', () => {
      module.treeView = {
        selectedPaths() {
          return ['C:\\Users\\Username\\Tutorials\\work-in-progress\\tutorial-name\\images\\images\\tutorial-image.png'];
        },
      };
      module.insertTemplate();

      expect(notification.addError)
        .toHaveBeenCalledWith(
          MESSAGES.INSERT_LOCAL_IMAGE.NOTIFICATIONS.NO_EDITOR
            .replace('{{fileName}}', 'C:\\Users\\Username\\Tutorials\\work-in-progress\\tutorial-name\\tutorial-name.md')
        );
    });
  });
});

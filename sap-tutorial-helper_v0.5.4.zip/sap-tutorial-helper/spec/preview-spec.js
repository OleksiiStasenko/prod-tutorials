'use babel';

import path from 'path';
import constants from '../lib/constants';
import previewPackage from '../lib/modules/preview-package';
import specHelper from './spec-helper';

const { COMMON } = constants;

describe(`${COMMON.PLUGIN_NAME}:toggle-preview`, () => {
  let workspaceElement;
  let tutorialElement;
  let tutorialFolder;

  const previewCommand = `${COMMON.PLUGIN_NAME}:toggle-preview`;
  const tutorialPath = path.join(__dirname, 'data', 'valid.md');

  beforeEach(() => {
    specHelper.setQaRepoPath();
    specHelper.setAutoUpdate(false);
    atom.config.set(`${COMMON.PLUGIN_NAME}.environment`, 'developers-qa.sap.com|auth');

    waitsForPromise('package activation', () => atom.packages.activatePackage(COMMON.PLUGIN_NAME));

    runs(() => spyOn(atom.packages, 'hasActivatedInitialPackages')
      .andReturn(true));

    workspaceElement = atom.views.getView(atom.workspace);
    // by default it has height 0
    workspaceElement.style.minHeight = `${document.body.clientHeight}px`;
    tutorialElement = document.createElement('div');
    tutorialFolder = document.createElement('div');
    tutorialFolder.classList.add('file');
    workspaceElement.classList.add('tree-view');
    tutorialElement.setAttribute('data-name', 'valid.md');
    tutorialElement.setAttribute('data-path', tutorialPath);
    tutorialElement.classList.add('name');
    tutorialFolder.appendChild(tutorialElement);
    workspaceElement.appendChild(tutorialFolder);
    jasmine.attachToDOM(workspaceElement);
  });

  describe('Event dispatching', () => {
    const listener = jasmine.createSpy('onDidDispatch');

    beforeEach(() => {
      atom.commands.onDidDispatch((event) => {
        if (event.type === previewCommand) {
          listener();
        }
      });

      waitsFor(`dispatching ${previewCommand}`, () => atom.commands.dispatch(tutorialElement, previewCommand));

      waitsFor(':onDidDispatch handler to be called', () => listener.callCount > 0);
    });

    it('should dispatch the event', () => {
      expect(listener)
        .toHaveBeenCalled();
    });
  });

  describe('Open new Pane: response.ok', () => {
    beforeEach(() => {
      spyOn(window, 'fetch')
        .andCallFake(() => Promise.resolve({ ok: true }));

      spyOn(atom.workspace, 'open')
        .andCallThrough();

      return previewPackage.preview(tutorialElement);
    });

    afterEach(function () {
      this.removeAllSpies();
    });

    it('should call fetch', () => {
      waitsFor('fetch to be called', () => window.fetch.callCount > 0);
      runs(() => expect(window.fetch)
        .toHaveBeenCalled());
    });

    it('should call atom.workspace.open', () => {
      expect(atom.workspace.open)
        .toHaveBeenCalled();
    });

    it('should create pane', () => {
      waitsFor('atom.workspace.open to be called', () => atom.workspace.open.callCount > 0);
      waitsFor('fetch to be called', () => window.fetch.callCount > 0);

      runs(() => {
        const uri = `${COMMON.PLUGIN_NAME}://${encodeURI(tutorialPath)}`;
        const pane = atom.workspace.paneForURI(uri);

        expect(pane)
          .toBeDefined();
      });
    });
  });
  describe('Open new Pane: response.ok = false', () => {
    beforeEach(() => {
      spyOn(window, 'fetch')
        .andCallFake(() => Promise.resolve({ ok: false }));

      spyOn(atom.workspace, 'open')
        .andCallThrough();

      return previewPackage.preview(tutorialElement);
    });

    afterEach(function () {
      this.removeAllSpies();
    });

    it('should call fetch', () => {
      waitsFor('fetch to be called', () => window.fetch.callCount > 0);
      runs(() => expect(window.fetch)
        .toHaveBeenCalled());
    });

    it('should call atom.workspace.open', () => {
      expect(atom.workspace.open)
        .toHaveBeenCalled();
    });

    it('should create pane', () => {
      waitsFor('atom.workspace.open to be called', () => atom.workspace.open.callCount > 0);
      waitsFor('fetch to be called', () => window.fetch.callCount > 0);

      runs(() => {
        const uri = `${COMMON.PLUGIN_NAME}://${encodeURI(tutorialPath)}`;
        const pane = atom.workspace.paneForURI(uri);

        expect(pane)
          .toBeDefined();
      });
    });

    it('should show error message', () => {
      let pane;
      waitsFor('atom.workspace.open to be called', () => atom.workspace.open.callCount > 0);
      waitsFor('fetch to be called', () => window.fetch.callCount > 0);

      waitsFor('pane', () => {
        const uri = `${COMMON.PLUGIN_NAME}://${encodeURI(tutorialPath)}`;
        pane = atom.workspace.paneForURI(uri);

        return pane;
      });

      runs(() => {
        expect(pane.element.textContent.includes('Server is unavailable...'))
          .toBeTruthy();
      });
    });
  });
  describe('Open new Pane: response.ok = true', () => {
    beforeEach(() => {
      spyOn(window, 'fetch')
        .andCallFake(() => Promise.resolve({ ok: true }));

      spyOn(atom.workspace, 'open')
        .andCallThrough();

      return previewPackage.preview(tutorialElement);
    });

    afterEach(function () {
      this.removeAllSpies();
    });

    it('should call fetch', () => {
      waitsFor('fetch to be called', () => window.fetch.callCount > 0);
      runs(() => expect(window.fetch)
        .toHaveBeenCalled());
    });

    it('should call atom.workspace.open', () => {
      expect(atom.workspace.open)
        .toHaveBeenCalled();
    });

    it('should create pane', () => {
      waitsFor('atom.workspace.open to be called', () => atom.workspace.open.callCount > 0);
      waitsFor('fetch to be called', () => window.fetch.callCount > 0);

      runs(() => {
        const uri = `${COMMON.PLUGIN_NAME}://${encodeURI(tutorialPath)}`;
        const pane = atom.workspace.paneForURI(uri);

        expect(pane)
          .toBeDefined();
      });
    });

    it('should show error message', () => {
      let pane;
      waitsFor('atom.workspace.open to be called', () => atom.workspace.open.callCount > 0);
      waitsFor('fetch to be called', () => window.fetch.callCount > 0);

      waitsFor('pane', () => {
        const uri = `${COMMON.PLUGIN_NAME}://${encodeURI(tutorialPath)}`;
        pane = atom.workspace.paneForURI(uri);

        return pane;
      });

      runs(() => {
        expect(pane.element.textContent.includes('Loading tutorial preview...'))
          .toBeTruthy();
      });
    });
  });
});

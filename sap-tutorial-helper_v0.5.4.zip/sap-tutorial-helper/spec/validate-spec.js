'use babel';

import path from 'path';

import constants from '../lib/constants';
import ErrorHintModel from '../lib/modules/validator/view-providers/error-hint/model';
import tutorials from './data/tutorials';
import specHelper from './spec-helper';

const { COMMON, MESSAGES, CLASS_NAMES } = constants;

describe(`${COMMON.PLUGIN_NAME}:validate`, () => {
  let workspaceElement;
  let editor;
  let editorElement;

  beforeEach(() => {
    specHelper.setQaRepoPath();
    waitsForPromise('package activation', () => atom.packages.activatePackage(COMMON.PLUGIN_NAME));

    runs(() => spyOn(atom.packages, 'hasActivatedInitialPackages')
      .andReturn(true));

    workspaceElement = atom.views.getView(atom.workspace);
    jasmine.attachToDOM(workspaceElement);
    // by default it has height 0
    workspaceElement.style.minHeight = `${document.body.clientHeight}px`;
  });

  describe('validate on valid tutorial', () => {
    beforeEach(() => {
      waitsForPromise(
        'tutorial being opened',
        () => atom.workspace
          .open(path.join(__dirname, './data/valid.md'))
          .then((result) => {
            editor = result;
            return editor;
          })
      );

      runs(() => {
        editorElement = editor.getElement();
        jasmine.attachToDOM(editorElement);

        return specHelper.dispatchCommand(editorElement, `${COMMON.PLUGIN_NAME}:validate`);
      });
    });

    it('should create start notification', () => {
      const notifications = atom.notifications.getNotifications();
      const exists = notifications.some(n => n.message === MESSAGES.VALIDATION.START);

      expect(exists)
        .toBe(true);
    });

    it('should create end notification', () => {
      const notifications = atom.notifications.getNotifications();
      const exists = notifications.some(n => n.message === MESSAGES.VALIDATION.END_SUCCESS);

      expect(exists)
        .toBe(true);
    });

    it(`should not create element with ${CLASS_NAMES.ERROR_MESSAGE_OVERLAY} class name`, () => {
      expect(editorElement.querySelector(`.${CLASS_NAMES.ERROR_MESSAGE_OVERLAY}`))
        .not
        .toExist();
    });

    it('should not add decoration to gutter', () => expect(workspaceElement.querySelector(`.${CLASS_NAMES.LINE_NUMBER}`))
      .not
      .toExist());
  });

  describe('validate on invalid tutorial', () => {
    beforeEach(() => {
      waitsForPromise('tutorial being opened', () => atom.workspace
        .open(path.join(__dirname, './data/invalid.md'), { split: 'right' })
        .then((result) => {
          editor = result;
          return editor;
        }));

      runs(() => {
        editorElement = editor.getElement();
        jasmine.attachToDOM(workspaceElement);

        return specHelper.dispatchCommand(editorElement, `${COMMON.PLUGIN_NAME}:validate`);
      });
    });

    describe('decorations', () => {
      it('should create start notification', () => {
        const notifications = atom.notifications.getNotifications();
        const startNotification = notifications.find(n => n.message === MESSAGES.VALIDATION.START);

        expect(startNotification)
          .toBeDefined();
        expect(startNotification.options.dismissable)
          .toBeTruthy();
      });

      it('should create end notification', () => {
        const notifications = atom.notifications.getNotifications();
        const exists = notifications.some(n => n.message === MESSAGES.VALIDATION.END_ERROR);

        expect(exists)
          .toBe(true);
      });

      it('should add error hint decorations', () => {
        let errorHintModels = [];

        waitsFor(() => {
          const decorations = editor.getDecorations();
          errorHintModels = decorations
            .filter(d => ErrorHintModel.isErrorHintModel(d.properties.item));

          return errorHintModels.length > 0;
        }, 'all decorations being added', 750);

        runs(() => {
          expect(errorHintModels)
            .toHaveLength(tutorials.invalid.decorations);
        });
      });
    });

    describe('DOM changes', () => {
      let lineElement;
      let overlayElement;

      beforeEach(() => {
        const { bufferRow } = tutorials.invalid;

        waitsFor(() => {
          lineElement = editorElement.querySelector(`.line-number.${CLASS_NAMES.LINE_NUMBER}[data-buffer-row="${bufferRow}"]`);
          overlayElement = editorElement.querySelector(`.${CLASS_NAMES.ERROR_MESSAGE_OVERLAY}`);

          return !!(lineElement && overlayElement);
        }, 'all decorations being applied');

        runs(() => {
          expect(lineElement)
            .toExist();
          expect(overlayElement)
            .toExist();
        });
      });

      it('should hide overlay initially', () => {
        expect(overlayElement.classList.contains(CLASS_NAMES.HIDDEN))
          .toBe(true);
      });

      it('should toggle overlay visibility on line number hover', () => {
        specHelper.hover(lineElement, () => {
          expect(overlayElement.classList.contains(CLASS_NAMES.HIDDEN))
            .toBe(false);
        });
      });

      it('should hide overlay after hover end', () => {
        expect(overlayElement.classList.contains(CLASS_NAMES.HIDDEN))
          .toBe(true);
      });
    });
  });
});

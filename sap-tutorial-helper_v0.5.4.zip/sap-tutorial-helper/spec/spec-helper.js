'use babel';

import child_process from 'child_process';
import { sep } from 'path';

import constants from '../lib/constants';

const { COMMON } = constants;

function mouseEnter(element) {
  element.dispatchEvent(new CustomEvent('mouseenter', { bubbles: false }));
  element.dispatchEvent(new CustomEvent('mouseover', { bubbles: true }));
}

function mouseLeave(element) {
  element.dispatchEvent(new CustomEvent('mouseleave', { bubbles: false }));
  element.dispatchEvent(new CustomEvent('mouseout', { bubbles: true }));
}

function hover(element, fn) {
  mouseEnter(element);
  fn();
  mouseLeave(element);
}

function dispatchCommand(element, command) {
  const listener = jasmine.createSpy('onDidDispatch');

  atom.commands.onDidDispatch((event) => {
    if (event.type === command) {
      listener();
    }
  });

  waitsForPromise({ shouldReject: false, label: `dispatching ${command}` }, () => atom.commands.dispatch(element, command));

  waitsFor(':onDidDispatch handler to be called', () => listener.callCount > 0);
}

function setQaRepoPath() {
  atom.config.set(COMMON.QA_REPO_CWD_CONFIG_KEY, `${__dirname}${sep}${COMMON.QA_TUTORIALS_GIT_REPO}`);
}

function setForkRepoPath() {
  return atom.config.set(COMMON.PROD_REPO_CWD_CONFIG_KEY, `${__dirname}${sep}${COMMON.PROD_TUTORIALS_GIT_REPO}`);
}

function setAutoUpdate(value = false) {
  return atom.config.set(`${COMMON.PLUGIN_NAME}.autoUpdate`, value);
}

function spyOnExec() {
  spyOn(child_process, 'exec');
}

export default {
  dispatchCommand,
  hover,
  mouseEnter,
  mouseLeave,
  setAutoUpdate,
  setQaRepoPath,
  setForkRepoPath,
  spyOnExec,
};

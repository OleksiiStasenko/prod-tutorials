const path = require('path');
const fs = require('fs');
const util = require('util');

const AdmZip = require('adm-zip');
const packageMeta = require('../package');

const readDirAsync = util.promisify(fs.readdir.bind(fs));
const statAsync = util.promisify(fs.stat.bind(fs));

const excluded = ['node_modules', 'utilities', '.git', '.idea', 'package-lock.json'];

async function pack() {
  const zip = new AdmZip();
  const result = await readDirAsync(path.join(__dirname, '../'));
  const entries = result.filter(entry => !excluded.includes(entry));

  const promises = entries.map(async (entry) => {
    const entryPath = path.join(__dirname, '../', entry);
    const stat = await statAsync(entryPath);
    const isDir = stat.isDirectory();
    if (isDir) {
      return zip.addLocalFolder(entryPath, `${packageMeta.name}/${entry}`);
    } else {
      return zip.addLocalFile(entryPath, packageMeta.name);
    }
  });

  await Promise.all(promises);

  return zip.writeZip(`utilities/${packageMeta.name}_v${packageMeta.version}.zip`, (error) => {
    if (error) {
      console.error(error);
      return process.exit(1);
    }

    console.log('File created!');
  });
}

module.exports = pack;

'use strict';

const fs = require('fs');
const util = require('util');
const path = require('path');
const childProcess = require('child_process');

const packageMeta = require('../package');
const pack = require('./pack');

const execAsync = util.promisify(childProcess.exec.bind(childProcess));
const readDirAsync = util.promisify(fs.readdir.bind(fs));
const unlinkAsync = util.promisify(fs.unlink.bind(fs));

const projectPath = path.join(__dirname, '../');

const directory = 'utilities';
const excludedFile = '.gitkeep';

async function commit(version) {
  const addCommand = 'git add utilities/*';
  const commitCommand = `git commit -m "Add new zip v${version}"`;
  await execAsync(addCommand, { cwd: projectPath });
  return execAsync(commitCommand, { cwd: projectPath });
}

async function removeOldFiles(version) {
  const newFileName = `${packageMeta.name}_v${version}.zip`;
  const files = await readDirAsync(directory);

  return Promise.all(files.map((fileName) => {
    const isNewFile = fileName === newFileName;
    if (!(excludedFile.includes(fileName) || isNewFile)) {
      return unlinkAsync(path.join(directory, fileName));
    }

    return fileName;
  }));
}

async function build() {
  const { version } = packageMeta;

  console.log(`Creating new build: v${version}`);

  try {
    await pack();
    await removeOldFiles(version);
    await commit(version);
    process.exit();
  } catch (error) {
    console.log('Could not create new build');
    console.log(error);
    return process.exit(1);
  }
}

module.exports = build();

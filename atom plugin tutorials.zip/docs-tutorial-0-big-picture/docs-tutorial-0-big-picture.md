---
title: The Big Picture on Tutorials
description: Learn about SAP developer tutorials, groups and missions, and the high-level process for creating and publishing them.
primary_tag: topic>cloud
tags: [  tutorial>beginner, topic>cloud ]
time: 10
---

## Details
### You will learn  
  - The purpose of our tutorials
  - How tutorials are organized for our customer developers
  - The high-level process for creating and publishing tutorials
  - How to plan your tutorials

This tutorial gives you the big picture on how tutorials are made, both in their planning and in their technical production.

>This tutorial is the first in the tutorial group [Create Developer Tutorials](https://developers-qa.sap.com/group.docs-tutorial.html) that explains the tutorial creation process.


---

[ACCORDION-BEGIN [Step 1](Tutorials, groups and missions)]

We build **tutorials** for developers to get a taste of our technologies. Each tutorial is essentially a set of steps to perform, along with additional information (e.g., how long will the tutorial take, prerequisites, overview). A tutorial generally takes up to 20 minutes for a user with the designated skill level (Beginner, Intermediate or Advanced).

[View tutorials](https://developers.sap.com/tutorial-navigator.html)

![Tutorial](Tutorial.png)

A set of tutorials can be combined into a **tutorial group** that outline how to build a more sophisticated application or feature. Tutorial groups generally include 3 to 5 tutorials and take around an hour. With a group, a developer should have made some significant achievement in running or building an application.

[View tutorial groups](https://developers.sap.com/tutorial-navigator.html?tag=tutorial:type/group)

![Tutorial group](Group.png)

A set of tutorials or tutorial groups can be combined into a **mission** to provide the basics for learning a skill, for example, building UIs or managing an SAP Cloud Platform account or developing IoT applications. Missions are "high-level learning goals" that an external developer might have.

Missions are gamified, and you can earn badges as you complete the tutorials (this is a work in progress).

[View missions](https://developers.sap.com/app-space.html)

![Mission](mission.png)

### Developer Experience time goals

When planning your tutorial series, keep the following developer experience time goals in mind. The chart tells what a developer should accomplish in what amount of time.

Time&nbsp;limit    | Desired outcome
:------------: | :------------------------------------------------------------
5 min         | Survey what's available on the developer page, and decide what to dig into
5 min         | Sign up for first trial *–or–* read developer friendly info on a product
20 min        | Build first app
60 min        | Build second or third version of an app – adding interesting functionality
1 week        | Work through other tutorials of a product (2-3 hrs of time) and be able to report up to senior management
2 weeks       | Build something custom, refer to community resources
1 month       | Engage and become active in the community

### No Hello World apps
With the above goals in mind, we want to move away from "Hello World". Instead, our tutorials will do something *useful* (even if basic). For instance, if the result is to output text on a web page, instead of displaying `Hello World`, display the local time or weather in Paris, or call an API to retrieve information.

[ACCORDION-END]

[ACCORDION-BEGIN [Step 2](Planning tutorials)]
Planning is a key -- and often overlooked -- part of authoring tutorials.

When developing tutorials, you'll almost always want to build at least a group, so plan for the 3-5 tutorials that work together and are the desired length. Still, it's worth looking ahead at least 6-12 months, and maybe further, to what missions you'll want for your topic over the long term.

You don't have to build all your missions at once, but should have an idea of what missions and groups you will want.

![Mission](mission.png)

Work with a Developer Relations evangelist in your product area. The evangelist is extremely knowledgeable about SAP technologies and the other published tutorials, and will be responsible for approving all tutorials, so it's key to work together from the beginning.

>For the most up-to-date list of evangelists, see [Developer Evangelists](https://jam4.sapjam.com/groups/6Jr8GG1khjmOoSVZPK2GhG/overview_page/UDPBosuUV6NDxRWIzUWuPe). If you cannot find an evangelist for your area, contact [`Riley Rainey`](https://people.wdf.sap.corp/profiles/I838039).

>For ideas on how to construct missions, see the [SAP Cloud Platform missions](https://developers.sap.com/topics/cloud-platform.html#tutorials).

>Download a [planning Excel](https://jam4.sapjam.com/groups/6Jr8GG1khjmOoSVZPK2GhG/documents/qS7lEZAJnlnbSnEWiVKQoM) to help you organize your tutorials. Before authoring, you should outline the  titles, descriptions, and times for all missions, groups, and tutorials.

[ACCORDION-END]


[ACCORDION-BEGIN [Step 3](Tutorial production)]

The source of tutorials are located in 2 GitHub repositories:

  - [`Tutorials-Contributions`](https://github.com/SAPDocuments/Tutorials-Contribution) (need authorization): These tutorials (in the `tutorials` folder) are published to the QA web site.
  - [`Tutorials`](https://github.com/SAPDocuments/Tutorials): These tutorials (in the `tutorials` folder and copied from the `tutorials` folder from `Tutorials-Contribution`) are published to the production web site.


Tutorials are created as follows:

1. Send tutorial outline to your evangelist and [Daniel Wroblewski](https://people.wdf.sap.corp/profiles/I031617).

2. Write tutorials as a Markdown file (using Atom editor and the SAP Preview plugin).

    - As you work, you can see a preview of your tutorial.

    - Each tutorial file is in its own folder with the same name. The folder also contains images for your tutorial.

3. Check tutorials for spelling and broken links (using an Atom command).

4. Commit and push the tutorial to SAP's `Tutorials-Contribution` repository on GitHub (using a plugin command).

5. View the tutorial on the [QA website](https://developers-qa.sap.com/index.html) (credentials `wcms`/`wcms`).

6. Move tutorials to production by copying them to your fork of SAP's [`Tutorials`](https://github.com/SAPDocuments/Tutorials) repository, and making a pull request.

>Anything added to the `tutorials` folder of SAP's `Tutorials-Contribution` repository automatically is published to the QA website. Use the `work-in-progress` folder for initial drafts that are not ready and do not yet pass the validation tests.

>Anything added to the `tutorials` folder of SAP's `Tutorials` repository automatically is published to the production website.

[ACCORDION-END]

[ACCORDION-BEGIN [Step 4](Sample code / projects)]

There may be times when you don't want developers to start from scratch, but instead download a skeleton project or other executable. You can set this up on [SAP's GitHub account](https://github.com/SAP), but must go through SAP's [Sample Code Publication Process](https://jam4.sapjam.com/wiki/show/Hiyj9CHle4yvln6QpdDmXo).

![SAP on GitHub](SAP-GitHub.png)

Don't worry.

I am told that, in most cases, it will take no more than a week to set get approval and set up everything -- as long as you are not exposing any private APIs. The process is essentially:

  - Get permission (couple of days)
  - Put files on SAP account on GitHub (couple of days)

To get started, contact [Brian Bernard](https://people.wdf.sap.corp/profiles/I828723).

[ACCORDION-END]


---

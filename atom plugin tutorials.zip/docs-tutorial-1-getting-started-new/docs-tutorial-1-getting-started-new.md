---
title: Get Ready to Write Tutorials
description: Set up your environment to write tutorials, including installing all the necessary tools.
primary_tag: topic>cloud
tags: [  tutorial>beginner, topic>cloud, tutorial>license  ]
time: 30
---

## Details
### You will learn  
 - How to plan for writing tutorials
 - How to install the necessary tools
 - How to clone the needed repositories

Writing developer tutorials requires a few simple tools, such as for running scripts to help you create and test your tutorials, as well as updating the tutorial GitHub repository with your files.

>Some people have reported issues connecting to GitHub via VPN, though others have no problem working with a VPN.

### What you need to know
To make tutorials, you will need to be familiar with the following:

  - **Markdown**: Markdown is an easy-to-use markup language, similar to wiki markup, for building a structured documents. It is worth 20 minutes to get familiar with Markdown.

    - For newbies, check out this [this reference](http://commonmark.org/help/) and this [10 minutes tutorial](http://commonmark.org/help/tutorial/).
    - On GitHub, however, we use `GitHub Flavored Markdown`, which has [differences to traditional Markdown](https://help.github.com/articles/github-flavored-markdown/) like table, code block syntax highlighting, and URL auto linking.
    - If you're already familiar with Markdown but need to refresh your memory, check out the [Markdown Cheat Sheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet).

    >Our [style guide](https://github.com/SAPDocuments/Tutorials-Contribution/blob/master/templates/styleguide.md) provides guidance on the Markdown formatting you'll need for tutorials.

  - **Git**: Git is a widely used source control system, and you will use it to check in and check out your files. It is worth an hour to get familiar with it.

    - [Understanding the `Github flow`](https://guides.github.com/introduction/flow/)
    - [GitHub Hello World](https://guides.github.com/activities/hello-world/)
    - [GitHub Overview & Training Webcasts](https://www.youtube.com/playlist?list=PLg7s6cbtAD15Das5LK9mXt_g59DLWxKUe)

    You won't have to do complex stuff with Git -- and our plugin provides menu options so you can bypass it for the most part. Still, you should be familiar with how Git works -- you will need sometimes to work directly with Git.

### What you need to have

Before you start this tutorial, you will need:

  - A [GitHub](https://github.com/) account
  - Permission to the `Tutorial-Contributions` repository in the `SAPDocuments` GitHub account. Please contact [`Daniel Wroblewski`](https://people.wdf.sap.corp/profiles/I031617).

    Once you are given permission, you should receive an email to join the SAPDocuments organization (and thereby the `Tutorials-Contributions` repository).

    ![Invitation](Email.png)  

    If you lose the email, you can always go to your notifications on GitHub by clicking ...

    ![Notification icon](NotificationIcon.png)

    ... in the upper right and accept the invitation there.

    ![NotificationAccept](NotificationAccept.png)  

    Alternatively, you can go to the [SAPDocuments](https://github.com/SAPDocuments) organization on GitHub and accept the invitation there.

---

[ACCORDION-BEGIN [Step 1: ](Plan your missions)]
Before writing any tutorials, you need to do some planning with your stakeholders:

  - What high-level missions do you want to create over the next 6 to 12 months?
  - How do you want to break down the content into missions, groups, and tutorials?

>Use this [planning Excel](https://jam4.sapjam.com/groups/6Jr8GG1khjmOoSVZPK2GhG/documents/qS7lEZAJnlnbSnEWiVKQoM) for creating an outline and managing your QA workflow.

Before starting to write, you should have the following information for each mission, group and tutorial:

  - Title
  - Description
  - Estimated time to complete

You'd be surprised, but working just on the titles, descriptions, and time will help you author better tutorials.

[ACCORDION-END]


[ACCORDION-BEGIN [Step 2: ](Install prerequisites)]
Install the following open-source tools on your workstation (and afterwards restart your computer):

| Tool                                                 | Description         | Install Notes |
| :--------------------------------------------------  |---------------------|---------------|
| [Node.js](https://nodejs.org/)                       | The Node.js framework lets us run JavaScript apps for creating and testing tutorials. | Run installer with defaults |
| [Git for Windows](http://gitforwindows.org/) or [Git for Mac](https://gist.github.com/derhuerst/1b15ff4652a867391f03#file-mac-md) | Git lets you interact with our GitHub repositories. <div>&nbsp;</div><div> **NOTE: This is different from GitHub Desktop.**</div>    | Run installer with defaults.  |  
| [Atom Editor](https://atom.io/)                      | The Atom editor is designed as an editor for Markdown (`.md`) files, which is the format of tutorial files.  | Run installer with defaults |  

>**Mac Users:** Cache your password by following the instructions [here](https://help.github.com/articles/caching-your-github-password-in-git/#platform-mac).

Restart your computer.

[ACCORDION-END]



[ACCORDION-BEGIN [Step 3: ](Update GitHub account)]
Go to [GitHub](https://github.com/), sign in, and open your profile settings.

![Open GitHub profile](OpenGithubProfile.png)

Make sure your name is listed properly, and add a picture. Your GitHub name, and your picture, will appear as the author when you publish tutorials. Also fill in your company.

![GitHub profile settings](ChangeGithubProfile.png)

Make sure to verify your email address and set it as your primary email address. This will be the email to identify your commits.

![Set email address](PrimaryEmails.png)

[ACCORDION-END]

[ACCORDION-BEGIN [Step 4: ](Set author name in Git)]
The author listed for a tutorial is the name on the last commit by the author who first committed the tutorial. So you need to set up the name that should appear for your commits.

Open a command prompt ( **Win+X**, then press **A** ), then run the following command, replacing `FIRST_NAME` and `LAST_NAME` with your name:

```Git
git config --global user.name "FIRST_NAME LAST_NAME"
```

>If ever you need to change the name that appears at the top of a tutorial, add the following metadata at the start of the Markdown file for that tutorial.
```Metadata
author_name: Daniel Wroblewski
author_profile: https://github.com/thecodester
```

[ACCORDION-END]

[ACCORDION-BEGIN [Step 6: ](Install plugin)]

Our `sap-tutorial-helper` plugin to the Atom editor will let you do all your tasks within the Atom editor, and will hide many of the Git tasks.


>**IMPORTANT:** You need permission to the QA repo (`Tutorials-Contribution`) to download the plugin, and to be logged into GitHub.

Click [Atom Plugin for SAP Tutorials](https://github.com/SAPDocuments/Tutorials-Contribution/blob/master/utilities), then click on the latest version of the `sap-tutorial-helper` zip file, and choose **Download**.

![Download plugin](DownloadPlugin.png)

Extract the contents (use **Extract Here**), and run the installer in the `install` directory (`win.bat` for Windows, `unix.sh` for Mac via terminal).  

### Troubleshooting

  - If you get an error `npm is not recognized as an internal or external command,
operable program or batch file`, then go back to the `install` folder and run the `update_path.bat` file, and then try to install the plugin again.  

  - If you get a proxy error or the process takes too long, you may need to set your proxy.

    Open a command prompt, and run the following commands:

    ```Config
    npm config set proxy http://proxy:8080
    npm config set https-proxy http://proxy:8080

    git config --global http.proxy http://proxy:8080
    git config --global https.proxy http://proxy:8080
    ```

    If you need to reset the proxy settings, run these commands:

    ```Config
    npm config rm proxy
    npm config rm https-proxy

    git config --global --unset http.proxy
    git config --global --unset https.proxy
    ```

    >For Mac users, Chris Whealy has created a Bash script for setting and unsetting proxy settings. See <https://github.wdf.sap.corp/I003638/proxy_settings>.

    Sometimes people still get proxy issues despite these settings. Sometimes, changing Windows proxy settings can help.

      1.  Click **Windows-S** to open Windows search, search for **`proxy`** and select **Change proxy settings**.

          ![Change proxy settings](TS-proxy.png)

      2. Set **Automatically detect settings** to **`On`**.

[ACCORDION-END]

[ACCORDION-BEGIN [Step 7: ](Clone Tutorials-Contribution repository)]
To do this step, you must have been granted permission to the `Tutorials-Contribution` repository.

1. Open a command prompt to the folder you want to put the local repository. On my Windows machine, I created a directory `C:\GitHub` where I put all my Git repositories.

    Then I opened a file explorer to this directory, right-clicked, and chose **Git Bash Here**.

    ![Git Bash](gitbash.png)

2. In the Git Bash window, issue the following command:

    ```Git
    git clone https://github.com/SAPDocuments/Tutorials-Contribution.git
    ```

    When the cloning finishes (it can take 10-15 minutes), you can check the directory to make sure the repository cloned, something like this:

    ![Local Tutorials-Contribution repository](LocalRepository.png)


[ACCORDION-END]

[ACCORDION-BEGIN [Step 8: ](Fork Tutorials repository)]
Later, when you publish your tutorial to production, you will need to make a copy (i.e., a fork) of the production tutorial repository, which is called `Tutorials`. The copy will be in your GitHub account, and you will update your copy and then request that your changes be merged into the production repository (in the `SAPDocuments` account).

Don't worry about the whole process. Let's just set up your copy of the production repository.

In GitHub, go to the [`SAPDocuments/Tutorials`](https://github.com/SAPDocuments/Tutorials) repository, and click **Fork**.

![Fork](Fork.png)

Select your account, and the fork will be created in your account.

![Fork in your account](ForkResult.png)

[ACCORDION-END]



[ACCORDION-BEGIN [Step 9: ](Clone Tutorials fork)]
Just as we cloned the `Tutorials-Contributions` repository, we'll clone the `Tutorials` repository.

>**IMPORTANT:** While you cloned the official `Tutorials-Contribution` repository from the `SAPDocuments` account, you'll now clone the `Tutorials` repository from your account.    

Open a command prompt to the folder you want to put the local repository. On my machine, I created a directory `C:\GitHub` where I put all my Git repositories.

Then, issue the following commands (change **`XXX`** to the name of your GitHub account).

```Git
git clone https://github.com/XXX/Tutorials.git
cd Tutorials
git remote add upstream https://github.com/SAPDocuments/Tutorials.git
```

[ACCORDION-END]



[ACCORDION-BEGIN [Step 10: ](Sign CLA)]
To send pull requests to the production repository (`Tutorials`), you must sign a Contributor License Agreement (CLA). You can do this when you submit a pull request, or you can do it now.

To sign the agreement, go to [https://cla-assistant.io/SAPDocuments/Tutorials](https://cla-assistant.io/SAPDocuments/Tutorials), and press **Sign in with GitHub to agree**. You may need to authorize the CLA assistant to use your GitHub account.

>The CLA is signed for your GitHub account, specifically for the email listed in GitHub for you. If you make commits that have a different email address associated with them, the CLA is not considered signed for those commits.

[ACCORDION-END]



[ACCORDION-BEGIN [Step 11: ](Open Atom)]
Open the Atom editor.

The first time you use the Atom Plugin for SAP Tutorials, you will be asked to specify the folder that contains the QA repository (e.g., on my machine, `C:\GitHub\Tutorials-Contributions`).

![Atom](EnterQARepo.png)

Specify the QA repository, and then you will have the QA `tutorials` and `work-in-progress` folders in your **Project** pane.

![Atom start](AtomView.png)

### Check your installation

Check your Atom editor and plugin installations by going to **File** | **Settings** | **Packages**, and see that the preview package -- officially `sap-tutorial-helper` -- is installed.

![Atom editor check](CheckAtom.png)

Click **Settings**, and there are a couple of settings you can adjust.

  - **Live Update:** Indicates whether you want the SAP preview to refresh as you type. This is a nice feature.
  - **Live Update Delay:** Indicates, in milliseconds, how long to wait after stopping to type in your tutorial file before refreshing the preview (if Live Update is turned on). The default is 1000 (1 second), but you might prefer a longer delay. Try 2 to 5 seconds.

  ![Atom editor check](CheckAtomSettings.png)

[ACCORDION-END]


---

---
title: Publish a Tutorial to Production
description: Learn how to publish your tutorial to the live SAP developer's Tutorial Navigator.
primary_tag: topic>cloud
tags: [  tutorial>beginner, topic>cloud ]
time: 5
---

## Details
### You will learn  
  - How to update your fork
  - How to move your tutorial to your fork
  - How to request to move your tutorial to production

To publish a tutorial, you copy your finished tutorial from the `Tutorials-Contribution` repository to your fork of the `Tutorials` repository. You must do this because you don't have access to the production `Tutorials` repository in the `SAPDocuments` account.

You then request that the tutorials be merged into the production `Tutorials` repository in the `SAPDocuments` account, by creating a pull request, which asks the `SAPDocuments` account to pull your changes into their repository.

Once in the production repository, an automatic process creates the tutorial page in the live [**Tutorial Navigator**](https://developers.sap.com/tutorial-navigator.html), usually within 5 minutes.

>**IMPORTANT!** Only move your tutorial to production once you have checked your tutorial (i.e., proofread, edited, checked the images), and once a local colleague and the evangelist for your area have reviewed and approved the tutorial.

>&nbsp;
>Some things to look out for:
>
> - Is all the text formatted OK?
    - Numbering is continuous.
    - Indents and spacing OK.
  - Are the images up-to-date?
  - Do the images show proprietary information (e.g., user IDs, URLs)
  - Are the titles and step titles in the correct format (i.e., start with simple verb, title case for titles, sentence case for steps).
  - Do all SAP names (of products and services) conform to branding guidelines. If you're not sure, check with the [Approved names](https://www.sapbrandtools.com/naming-center/#/search/status-search) and with your local User Assistance professional.

---


[ACCORDION-BEGIN [Step 1: ](Update your fork)]
Open GitHub Desktop, and do the following:

  1. Go to **Current repository**, and select your fork of the `Tutorials` repository.

      ![Select fork](UpdateFork1.png)

  2. Click **Fetch origin**.

      ![Fetch updates](UpdateFork2.png)

      This retrieves the state of the SAPDocuments `Tutorials` repository.

  3. In the menu, select **Branch** | **Merge into current branch**.

      ![Merge branch menu](UpdateFork3.png)

  4. Select `upstream/master`. You then can see the number of commits you are behind the SAPDocuments `Tutorials` repository, and that need to merged into your fork.

      ![Select upstream](UpdateFork4.png)

    >If after clicking `upstream/master` it says **Nothing to merge**, then your fork is already updated and you can skip to Step 2.

    >![Select upstream](UpdateFork5.png)

  5. Click **Merge into master**.

      You will now see new commits in the **History** tab.

[ACCORDION-END]

[ACCORDION-BEGIN [Step 2: ](Copy tutorial to your fork)]
On your local file system, copy and paste the entire folder containing your tutorial -- from the `tutorials` folder of the `Tutorials-Contribution` repository, to the `tutorials` folder of your fork of the `Tutorials` repository.

> This is done on your local copies of these repositories.  

![Copy tutorial](CopyTutorial.png)

[ACCORDION-END]


[ACCORDION-BEGIN [Step 3: ](Commit and push to your fork)]
1. In GitHub Desktop, go to your fork of `Tutorials` and look in the **Changes** tab. Here you will see that the tutorials files were added to your fork.

    ![Changed files](CommitTutorial.png)

2. Add a commit message and click **Commit to master**.

    On the **Push to origin** button, you should now see an up-arrow, which means you have commits that need to be pushed to your remote copy of your fork. The number is the number of commits, now equal to the number of commits to make your fork up to date with the production repository, plus the one commit for your new tutorial.

    ![One more commit](Commit.png)

2. Click **Push origin**.


[ACCORDION-END]


[ACCORDION-BEGIN [Step 4: ](Create pull request)]
1. Click **Branch** | **Create pull request**.

    This will take you to the GitHub web site, to a page that compares your changes to your fork with the current state of the production repository. You can see what changes you made – and more importantly, the changes you are asking the `SAPDocuments` account to accept.

    ![Pull request](PullRequest.png)

2. Look through the changes and make sure you are only changing your own files, and the changes makes sense to you.

3. If everything is OK, click **Create pull request**, enter a name for the pull request. and click **Create pull request**.

You can check your pull request by going to the [list of open pull requests](https://github.com/SAPDocuments/Tutorials/pulls) for the `SAPDocuments/Tutorials` repository. Yours should be listed there.

![List of pull requests](PullRequestList.png)

Someone on the evangelists team will review your changes and, if all is OK, merge them into the production repository.

[ACCORDION-END]

---
title: Create a Tutorial Mission or Group
description: Put a set of tutorials together to form a tutorial mission or group, so users can perform a more substantial and meaningful task.
primary_tag: topic>cloud
tags: [  tutorial>beginner, topic>cloud ]
time: 5
---

## Details
### You will learn  
  - How to request a tutorial mission or group

Even before publishing your tutorials, you should have been in consultation with evangelists and [Daniel Wroblewski](https://people.wdf.sap.corp/profiles/I031617) to design your missions and groups.

Once your tutorials are publishing, make a formal request for missions or groups.

---

[ACCORDION-BEGIN [Step 1: ](Create group entry)]
Copy the following code, modify it for your group, and add it to `tutorials-grouping.md` (located in the root of the `Tutorials-Contribution` repository; here's a link to [the file on GitHub](https://github.com/SAPDocuments/Tutorials-Contribution/blob/master/tutorial-grouping.md)).

Add the code to your area in the file, for example, `## SAP S/4HANA`. If your area is not listed, create a new heading.

```Markdown
  ---

  [Group Page]

  - **Group ID:** `myproduct-mytopic-myspecifictopic`
  - **Title:** Create something (sentence case, imperative verb)
  - **Experience** Intermediate
  - **Description:** Create someting with something else (your description)
  - **Icon:** `/content/dam/application/shared/icons/dev-jam.svg`
  - **Primary Tag:** `Products : SAP Jam`
  - **Tags:** `Products : SAP Jam`
  - **Time to complete:** 65 min

  - Tutorials:

    ```
    - /content/sapdx/website/languages/en/developer/tutorials/jam-cloud-setup-trust
    - /content/sapdx/website/languages/en/developer/tutorials/jam-cloud-api-sso-configure
    - /content/sapdx/website/languages/en/developer/tutorials/jam-cloud-webide-destination-configure
    - /content/sapdx/website/languages/en/developer/tutorials/jam-cloud-webide-plugins-activate
    - /content/sapdx/website/languages/en/developer/tutorials/jam-cloud-ui5-sample-build-project
    ```

  1. [Title of tutorial 1](https://developers.sap.com/tutorials/jam-cloud-setup-trust.html)
  2. [Title of tutorial 2](https://developers.sap.com/tutorials/jam-cloud-api-sso-configure.html)
  3. [Title of tutorial 3](https://developers.sap.com/tutorials/jam-cloud-webide-destination-configure.html)

  ---

```

>DO NOT add the links to the group or to your production tutorials, since they will break the build.

[ACCORDION-END]

[ACCORDION-BEGIN [Step 2: ](Commit and push)]
With the GitHub Desktop, commit and push your change of the `tutorials-grouping.md` file.  

![Commit and push](CommitAndPush.png)

[ACCORDION-END]


[ACCORDION-BEGIN [Step 3: ](Notify administrator)]
Copy the code that you modified in Step 1, copy it in an email, and request a group from [Daniel Wroblewski](https://people.wdf.sap.corp/profiles/I031617).

[ACCORDION-END]

---
title: Create a New Tutorial
description: Create a tutorial from scratch, test it, and deploy it to the QA server.
primary_tag: topic>cloud
tags: [  tutorial>beginner, topic>cloud  ]
time: 15
---

## Details
### You will learn  
  - How to create a new tutorial
  - How to preview the tutorial in the Atom editor
  - How to test your tutorial
  - How to move the tutorial to the QA system

You will create your tutorial in the `work-in-progress` folder, then move it to the local QA `tutorials` folder (after you run the test script and the tutorial passes), and then commit and push the tutorials to the remote GitHub repository.

If you're going to work on the tutorial for a while before moving it to QA and you want to make sure it is saved on the server, then you can commit your changes when the tutorial is still in the `work-in-progress` folder. See **Step 8** for how to commit changes to GitHub.

>To learn how to use Markdown formatting, see our [style guide](https://github.com/SAPDocuments/Tutorials-Contribution/blob/master/templates/styleguide.md).

>&nbsp;

> Make sure all SAP names (of products and services) conform to branding guidelines. If you're not sure, check with the [Approved names](https://www.sapbrandtools.com/naming-center/#/search/status-search) and with your local User Assistance professional.

---



[ACCORDION-BEGIN [Step 1: ](Create new tutorial from template)]
Open a command prompt, and navigate to the directory that contains your `Tutorials-Contribution` repository. Then run `node` `new`, and follow the prompts in the script.

![node new](NodeNew.png)

You will be asked for the following:

| Field | Description |
|:---------------------------|:--------------------------------|
| Tutorial Name             | This will be the name of the tutorial file (plus the extension `.md`), the folder containing the tutorial file, and (eventually) the URL path (plus the extension `.html`) to your tutorial on the QA and production systems.<br><br>Follow these rules for naming tutorials:<br><br><ul><li>Up to 6 keywords in all lowercase connected by hyphens</li><li>No underscores</li><li>No buzz or stop words, as described in [`stopwords.md`](https://github.com/SAPDocuments/Tutorials-Contribution/blob/master/templates/stopwords.md)</li><li>Do not use `sap`.</li><li>Less than 50 characters</li><li>No umlauts (replace them with the character plus an e)</li></ul>See below for an example.  |
| Tutorial Title            | This is the tutorial display title that people will see. Use title case, meaning all words are capitalized except small prepositions and articles (e.g., `the`, `an`). Do not use a colon ( **`:`** ) in the title.|
| Tutorial Description      | This is the short description that will appear under the title -- it is similar in format to title just expanded to about 20 words. Start with verb (no `-ing`), add context to the title, and end with period. |
| Tags                      | Pick at least 2 tags -- the difficulty level and at least one other tag. These tags are used to categorize the tutorial in search and on product pages. |
| Primary Tag               | This should be one of the tags you selected in the previous field. |
| Time               | The time the average developer will need to complete the tutorial. |

> You can use any valid 1DX tag. If you want to use a tag not in the Node.js script, let us know and we will add it.


### How to name tutorials
The rules for naming tutorials is designed to make it easier to search for our tutorials.

Identify up to 6 unique keywords (remember, no SAP) that you think are most important. These keywords should represent what you think potential readers will be searching for. Test your assumption about the importance by looking solely at the keywords and ask yourself what one would expect to see based on them. If your answer represents what your tutorial is about, you are good to go.

Next, order your keywords by importance:

  1. Main product -- **`cp`**
  2. Sub-product (optional) -- **`webide`**
  3. Goal of tutorial -- **`sapui5-app-create`**
  4. Details on *how* you achieve goal (optional) -- **`template`**

Taking the examples above, the proposed filename could be:

```
cp-webide-create-sapui5-app-template
```

Finally, check the character count of your filename. It should be less than 50. The easiest way to check this is to use [this character count tool](http://embed.plnkr.co/moVlKM/).

[ACCORDION-END]


[ACCORDION-BEGIN [Step 2: ](Open tutorial file in Atom)]
When the script is finished, your tutorial is created in the `work-in-progress` folder of the `Tutorials-Contribution` repository on your computer.

Open the file in the Atom editor.

![Atom](Atom.png)

To make your life easier, you may want to add the `work-in-progress` and `tutorials` folders as project folders in Atom. This way you can have access to all tutorials in QA from within Atom, and easily navigate and open your tutorials.

  1. Go to **File** | **Add Project Folder**.
  2. Navigator to the `work-in-progress` folder of your local `Tutorials-Contribution` repository, and choose **Select Folder**.
  3. Navigator to the `tutorials` folder of your local `Tutorials-Contribution` repository, and choose **Select Folder**.

This will open the tree view, and you will be able to scroll and see all tutorials. You could instead add only your tutorial folders as project folders in the tree view.

![Project folders](ProjectFolder.png)

[ACCORDION-END]

[ACCORDION-BEGIN [Step 3: ](Modify basic metadata (if needed))]
The basic metadata is automatically entered when you run the `new` script, but you may want to add information, especially in the description.

![Basic metadata](BasicMetadata.png)

| Metadata              | Description                                              |
|:--------------------|:----------------------------------------------------------|
| `title`              | 5-10 words, title case |
| `description`        | A one-sentence description of what the tutorial is about in same format as title, but expanded, ending with period |
| `primary_tag` / `tags` | These will be used to categorize the tutorials and help users search for them. You MUST have a primary tag, or else the tutorial will not be generated in production. |

> In the published tutorial, the author who is listed is the person who first committed the tutorial file to GitHub. This is OK in most cases. But when the author leaves the company or the person committing to GitHub is not the author, you can manual set the author by adding the following metadata at the top of the tutorial:

>  - **`author_name`**:The display name of the author (any text)
>  - **`author_profile`**: A URL to the author's profile, generally on GitHub.

> You must include both metadata if you want to manually set the author.

When writing the title and description, take note of how they appear in the search results ...

![Title and description](TitleDescription.png)

... and at the top of each tutorial.

![Title and description](TitleDescription2.png)

[ACCORDION-END]


[ACCORDION-BEGIN [Step 4: ](Add extended intro text)]
You should add the following information at the start of the tutorial:

  - **You will learn** (required): A bulleted list of skills the developer will learn. So if I build a sales order app, the developer may learn more generically how to create an app from a template, how to deploy an app, and how to run an app.
  - **Prerequisites**: A bulleted list of anything the user may need to know or have to do the tutorial. IMPORTANT: Do not create links to previous tutorials in a group/mission -- these will be created automatically.

  - **Details**: Additional background information or longer prerequisites. Keep this section short.

> **IMPORTANT**: Do not repeat the information.
>
>  - **Title** is a 5-10 words saying what the developer will do (`Create a Sales Order with Mendix`)
>  - **Description** is the same but expanded to up to 20 words (`Create a sales order app with Mendix and deploy it to SAP Cloud Platform.`)
>  - **You will learn** are the skills I will learn (`How to set up Mendix`, `How to create an app with Mendix`, `How to deploy a Mendix app`)
>  - **Details** is any additional information, generally background information about the environment and tools.


Where to place all the intro text is indicated in the template.

![Extended metadata](ExtendedMetadata.png)



[ACCORDION-END]

[ACCORDION-BEGIN [Step 5: ](Add steps)]

The rest of the tutorial is made up of steps, placed within the `ACCORDION` tags. A few tips:

  - Make each step a logical standalone task. Avoid making steps too long, filled with sub-steps. Each step should be able to be completed in a couple of minutes.
  - The name of the step (entered in the parentheses) is sentence case, with only the first word and proper nouns capitalized.
  - Start each step with an imperative verb (e.g., `Create a file` or `Add metadata`).
  - Leave a space after the step number in brackets.  

![Steps](Accordions.png)

Check out the [tutorial coding and style guide](https://github.com/SAPDocuments/Tutorials-Contribution/blob/master/templates/styleguide.md) for more information on how to format your text within a step.

When you are done, save your tutorial file.

[ACCORDION-END]

[ACCORDION-BEGIN [Step 6: ](Preview tutorial)]
Right click your tutorial file in the project tree, and click **Preview as SAP Tutorial**. (With your Markdown file in focus, you can press **Alt-Shift-Q**.)

![Preview tutorial](Preview.png)

This opens a preview window so you can see how your tutorial will look when it is published online.

![Preview pane](Preview2.png)

>For some users, the first time they use the SAP previewer, the stylesheet does not display properly. Close the preview window, and open a new preview window. This solves the problem.


[ACCORDION-END]


[ACCORDION-BEGIN [Step 7: ](Test tutorial)]
Open up a command prompt and navigate to your local `Tutorials-Contribution` folder.

>In GitHub Desktop, you can do this by clicking the current repository ...
>
>![Select current repository](GDC-openprompt.png)
>
>... and then right-clicking the `Tutorials-Contribution` repository, and selecting **Open in Command Prompt**.
>
>![Select current repository](GDC-openprompt2.png)
>
>If you don't have Git installed, choose **Open without Git**.

In the command prompt, enter the following (replace `myproduct-mytutorial-topic` with the name of your tutorial, with no extension):

```
node test -fwi myproduct-mytutorial-topic
```

If you want to run the test on several tutorials whose names start the same way, you can just enter the common prefix like this:

```
node test -fwi myproduct-mytutorial
```

And if you want to run the test for a tutorial in the tutorials folder, change the `w` option to `t`, like this:

```
node test -fti myproduct-mytutorial-topic
```

>From time to time, we add new tests to the script, and may use new `node.js` packages, which are not installed on your machine. In such cases, you will get a **Cannot find module** error, like this.
![Missing module](ErrorMissing.png)
>Run `npm install` again at the command prompt, and in less than a minute the package is installed and you can re-run the test script.

The test will run on your tutorial, showing you any spelling mistakes, broken links and other issues. Please fix these issues before moving the tutorial to QA.

  - **no common English stop words allowed**: This means you used a common English word in the name of your tutorial file. See [`stopwords`](https://github.com/SAPDocuments/Tutorials-Contribution/blob/master/templates/stopwords.md).
  - **no useless hyperlinked terms**: This means you used one of the following words as part of a link text: `here`, `there`, `file`, `folder`, `this`, `page`.
  - **curly single quotes found**: Use straight apostrophe.

![Running node test](nodetest.png)

[ACCORDION-END]

[ACCORDION-BEGIN [Step 8: ](Move tutorial to local QA folder)]
Once the test finishes without errors, you can move the tutorial (folder and all files) from the `work-in-progress` folder to the `tutorials` folder. Once you commit and push the changes to the GitHub repository, the tutorial will be processed and a Web page will be created on the QA server for your tutorial.

Close the Atom editor, and in the same command prompt as in the previous step, run the command:

```
node ready
```

The tutorial is tested again and then automatically moved to the `tutorials` folder.

>**IMPORTANT:** If a process has access to your folder in the `work-in-progress` folder, than the script will not work. You must close all windows opened to that folder, and any other program that may have a lock on the folder.
&nbsp;
>Instead of running the script, you can simply cut and paste the folder from the `work-in-progress` folder to the `tutorials` folder. **Make sure you cut and not copy the folder.**

[ACCORDION-END]

[ACCORDION-BEGIN [Step 9: ](Commit changes to QA)]
In GitHub Desktop, you will see in the **Changes** tab your files ready to be pushed.

  1. Click **Fetch origin**.

      If there are any new changes from the server that you do not have in your repository, the button will now show **Pull origin** with the number of new commits. Click the button, and wait until your client is updated.

  2. In the **Changes** tab, enter a commit message and description, and click **Commit to master**.

      ![Commit tutorial](CommitChanges.png)

  3. Click **Push origin** button.

      ![Push to origin](PushOrigin.png)

      If your repository is not in sync when you make the push (either because you didn't do the first step or someone pushed new changes just before you were ready to push yours), the GitHub client will ask you to fetch and merge the latest commits from the server by clicking **Pull origin** or the menu **Repository** | **Pull**. This will create another commit (i.e., a merge commit). You can then click **Push origin** to push your 2 commits (your original commit and the merge commit).  

  4. To check that all is OK, go to [GitHub](https://github.com/SAPDocuments/Tutorials-Contribution/commits/master) and check the commits for the `Tutorials-Contribution` repository to see your commit.

      ![Commit on GitHub](Commits.png)

      Next to the commit their will either be a yellow circle (tests in process), check mark (all tests OK), or a red X (failed tests).

    >If there is a red X, click the X and you will see the tests and what failed. **Please correct the errors.**

    > ![CircleCI](CircleCI.png)

[ACCORDION-END]

[ACCORDION-BEGIN [Step 9: ](Check tutorial in QA)]
Within 10 minutes of pushing your tutorial to the `tutorials` folder of the `Tutorials-Contribution` repository, you can view your tutorial on the QA website.

If your tutorial is called `mytutorial-get-started`, then the URL would be:

**`https://developers-qa.sap.com/tutorials/mytutorial-get-started.html`**

Make sure it looks the way you intended. If not, make changes in the file, rerun the test script, commit and push to GitHub, and check the revised version on the QA website (Steps 5-9).

[ACCORDION-END]



---

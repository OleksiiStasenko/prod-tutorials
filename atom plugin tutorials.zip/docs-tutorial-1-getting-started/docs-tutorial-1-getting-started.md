---
title: Get Ready to Write Tutorials
description: Set up your environment to write tutorials, including installing all the necessary tools.
primary_tag: topic>cloud
tags: [ tutorial>beginner, topic>cloud ]
time: 30
---

## Details
### You will learn  
 - How to install the necessary tools
 - How to install Node.js dependencies
 - How to clone the needed repositories

Writing developer tutorials requires a few simple tools, such as for running scripts to help you create and test your tutorials, as well as updating the tutorial GitHub repository with your files.

>It is best not to work on a VPN connection. This may cause connection issues with GitHub.  

### Prerequisites

Before you start this tutorial, you will need:

  - A [GitHub](https://github.com/) account
  - Permission to the `Tutorial-Contributions` repository in the `SAPDocuments` GitHub account. Please contact [`Daniel Wroblewski`](https://people.wdf.sap.corp/profiles/I031617).

    Once you are given permission, you should receive an email to join the SAPDocuments organization (and thereby the `Tutorials-Contributions` repository).

    ![Invitation](Email.png)  

    If you lose the email, you can always go to your notifications on GitHub by clicking ![Notification icon](NotificationIcon.png) in the upper right and accept the invitation there.

    ![NotificationAccept](NotificationAccept.png)  


---

[ACCORDION-BEGIN [Step 1: ](Install tools)]
You will need to install on your workstation the following open-source tools:

| Tool                                                 | Description         | Install Notes |
| :--------------------------------------------------  |---------------------|---------------|
| [Node.js](https://nodejs.org/)                       | The Node.js framework lets us run JavaScript apps for creating and testing tutorials. | Run installer with defaults |
| [GitHub&nbsp;Desktop&nbsp;Client](https://desktop.github.com/) | GitHub Desktop lets you use git source control to update your files in the tutorials GitHub repository.  | Run installer with defaults |
| [Atom Editor](https://atom.io/)                      | The Atom editor is designed as an editor for Markdown (`.md`) files, which is the format of tutorial files.  | Run installer with defaults |  
| [Atom Plugin for previewing SAP tutorials](https://github.com/SAPDocuments/Tutorials-Contribution/blob/master/utilities/sap-markdown-preview.zip) <br><br>(Requires permission to QA GitHub repository, and you must be signed in)  | The SAP Markdown Preview plugin lets you see how your tutorial will look once it is deployed online at `sap.com`.     | <br><ol><li>Click on the link and choose **Download** (you must be logged into GitHub and have permissions to see the file).</li><li>Extract the contents (use **Extract Here**), and run the installer in the `install` directory (`win.bat` for Windows, `unix.sh` for Mac).</li></ul> |  
| [Git for Windows](http://gitforwindows.org/) (optional) | Git for Windows will let you run Git commands from the command prompt.     | Run installer with defaults. In the **Adjusting your PATH environment** window, select `Use Git from the Windows Command Prompt.` |  

### Check your installation
You can check your Node.js installation by opening a command prompt and typing `node -v`, which should show you the version of your node installation.

Check your Atom editor and plugin installations by opening the Atom editor, then going to **File** | **Settings** | **Packages**, and see that the preview package is installed.

![SAP Markdown Preview](PreviewSettings.png)

There are 2 settings you can adjust:

  - **Live Update:** Indicates whether you want the SAP preview to refresh as you type. This is a nice feature.
  - **Live Update Delay:** Indicates, in milliseconds, how long to wait after typing in your tutorial file before refreshing the preview (if Live Update is turned on). The default is 1000 (1 second), but you might prefer a longer delay. Try 5 or 10 seconds.

[ACCORDION-END]



[ACCORDION-BEGIN [Step 2: ](Update GitHub account)]
Go to [GitHub](https://github.com/), sign in, and open your profile settings.

![Open GitHub profile](OpenGithubProfile.png)

Make sure your name is listed properly, and add a picture. Your GitHub name, and your picture, will appear as the author when you publish tutorials. Also fill in your company.

![GitHub profile settings](ChangeGithubProfile.png)

Also, make sure to verify your email address and set it as your primary email address. This will be the email to identify your commits (and later we will make sure it is set in your GitHub Desktop).

![Set email address](PrimaryEmails.png)

[ACCORDION-END]


[ACCORDION-BEGIN [Step 4: ](Clone Tutorials-Contributions repository)]
To do this step, you must have been granted permission to the `Tutorials-Contribution` repository.

1. Open GitHub Desktop.

2. Go to **File** | **Options**

3. Next to **`GitHub.com`**, click **Sign in** and sign in to your GitHub account.

    ![Connect client to GitHub account](SignInToGithub.png).

4. In the **Git** tab, make sure your full name (first and last names, separated by a space) and email are listed properly.

    ![Git tab](GitTab.png)

    >This is important, since all your commits are submitted with this name, and this name is listed as the author of the tutorial.

5. Choose **Save**.
6. Go to **File** | **Clone repository**. Under **`GitHub.com`**, you should see your repositories plus any others you have permission to.
7. Under **`GitHub.com`**, select `SAPDocuments/Tutorials-Contribution`, select the path to store the Git repository, and click **Clone**. You can create a directory called `C:\GitHub` to store all your GitHub repositories or choose any other location.

When the cloning finishes (it can take 10-15 minutes), you can check the directory to make sure the repository cloned, something like this:

![Local Tutorials-Contribution repository](LocalRepository.png)

>There's a shortcut to open the file explorer. In GitHub Desktop, click on the **Current Repository** (upper left), right-click on the Tutorials-Contribution repository, and choose **Show in Explorer**.
![Open command prompt](OpenCommand.png)


[ACCORDION-END]



[ACCORDION-BEGIN [Step 5: ](Fork Tutorials repository)]
Later, when you publish your tutorial to production, you will need to make a copy (i.e., a fork) of the production tutorial repository, which is called `Tutorials`. The copy will be in your GitHub account, and you will update your copy and then request that your changes be merged into the production repository (in the `SAPDocuments` account).

Don't worry about the whole process. Let's just set up your copy of the production repository.

In GitHub, go to the [`SAPDocuments/Tutorials`](https://github.com/SAPDocuments/Tutorials) repository, and click **Fork**.

![Fork](Fork.png)

Select your account, and the fork will be created in your account.

![Fork in your account](ForkResult.png)

[ACCORDION-END]



[ACCORDION-BEGIN [Step 6: ](Clone Tutorials repository)]
Just as we cloned the `Tutorials-Contributions` repository, we'll clone the `Tutorials` repository.

>**IMPORTANT:** While you cloned the official `Tutorials-Contribution` repository from the `SAPDocuments` account, you'll now clone the `Tutorials` repository from your account.    

1. Open GitHub Desktop.
2. Go to **File** | **Clone repository**. Under **`GitHub.com`**, you should see your repositories plus any others you have permission to.

    ![Clone fork of Tutorials](CloneFork.png)

3. Under **`GitHub.com`**, select `Tutorials` from your account (NOT `SAPDocuments/Tutorials`), select the path to store the git repository  and click **Clone**. If you created the directory `C:\GitHub` to store all your GitHub repositories, your path will be `C:\GitHub\Tutorials`.

[ACCORDION-END]



[ACCORDION-BEGIN [Step 7: ](Install Node.js dependencies)]

Open a command prompt, and change the current directory to the directory containing your local `Tutorials-Contribution` repository.

Run the following (make take up to 5 minutes):

```
npm install
```

This installs all the Node.js files needed to run the helper scripts. Ignore any warnings.

![npm install](npminstall.png)

[ACCORDION-END]



[ACCORDION-BEGIN [Step 8: ](Sign CLA)]
To send pull requests to the production repository (`Tutorials`), you must sign a Contributor License Agreement (CLA). You can do this when you submit a pull request, or you can do it now.

To sign the agreement, go to [https://cla-assistant.io/SAPDocuments/Tutorials](https://cla-assistant.io/SAPDocuments/Tutorials), and press **Sign in with GitHub to agree**. You may need to authorize the CLA assistant to use your GitHub account.

>The CLA is signed for your GitHub account, specifically for the email listed in GitHub for you. If you make commits that have a different email address associated with them, the CLA is not considered signed for those commits.

[ACCORDION-END]




---
